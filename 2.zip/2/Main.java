public class Main {
    public static void main(String[] args) {
        String filename = "test.txt";
        boolean stepMode = false;

        if (args.length >= 1) filename = args[0];
        if (args.length >= 2 && args[1].equalsIgnoreCase("step")) stepMode = true;

        Memory memory = new Memory(100);
        CompilerProgram compiler = new CompilerProgram(memory);
        compiler.compile(filename);

        SimpletronProcessorEngine s = new SimpletronProcessorEngine(memory);
        if (stepMode) s.step();
        else s.run();
    }
}