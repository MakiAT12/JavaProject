import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FileHandler {
    private final String filename;

    public FileHandler(String filename) {
        this.filename = filename;
    }

    public List<String> readSourceLines() {
        List<String> sourceLines = new ArrayList<>();

        try (Scanner scanner = new Scanner(new File(filename))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();

                // Remove comments
                if (line.contains(";"))
                    line = line.substring(0, line.indexOf(";"));

                line = line.trim();
                if (!line.isEmpty()) {
                    sourceLines.add(line);
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error: File not found - " + filename);
        }

        return sourceLines;
    }
}
