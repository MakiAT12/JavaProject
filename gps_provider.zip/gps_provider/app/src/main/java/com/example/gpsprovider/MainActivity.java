package com.example.gpsprovider;

import android.Manifest;
import android.app.Dialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

public class MainActivity extends AppCompatActivity {

    TextView lblLat, lblLong;
    Button btnOkey;

    FusedLocationProviderClient fusedLocationClient;
    LocationRequest locationRequest;
    LocationCallback locationCallback;

    Dialog loadingDialog;

    final int GPS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        lblLat = findViewById(R.id.lblLatitude);
        lblLong = findViewById(R.id.lblLongitude);
        btnOkey = findViewById(R.id.button);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Configure location request
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(500);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        // Configure location callback
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) return;

                double lat = locationResult.getLastLocation().getLatitude();
                double lng = locationResult.getLastLocation().getLongitude();
                lblLat.setText("LAT: " + lat);
                lblLong.setText("LNG: " + lng);

                // Hide loading dialog
                if (loadingDialog.isShowing()) {
                    loadingDialog.dismiss();
                }
            }
        };

        // Initialize loading dialog
        loadingDialog = new Dialog(this);
        loadingDialog.setContentView(R.layout.loading_screen);
        loadingDialog.setCancelable(false);

        // Make dialog window transparent
        if (loadingDialog.getWindow() != null) {
            loadingDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }


        ImageView locationIcon = loadingDialog.findViewById(R.id.locationIcon);
        Animation floating = AnimationUtils.loadAnimation(this, R.anim.floating);
        locationIcon.startAnimation(floating);

        // Button click listener
        btnOkey.setOnClickListener(v -> startLocationUpdates());

        // Request permission if not granted
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    GPS_PERMISSION_CODE);
        }


        ImageButton btnCopyLat = findViewById(R.id.btnCopyLatitude);
        btnCopyLat.setOnClickListener(v -> copyToClipboard("Latitude", lblLat.getText().toString()));

        ImageButton btnCopyLng = findViewById(R.id.btnCopyLongitude);
        btnCopyLng.setOnClickListener(v -> copyToClipboard("Longitude", lblLong.getText().toString()));

    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    GPS_PERMISSION_CODE);
            return;
        }

        // Show loading screen
        loadingDialog.show();

        // Start GPS updates
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, getMainLooper());
        Toast.makeText(this, "Getting location…", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        fusedLocationClient.removeLocationUpdates(locationCallback);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == GPS_PERMISSION_CODE &&
                grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Permission Required", Toast.LENGTH_SHORT).show();
        }
    }
    private void copyToClipboard(String label, String value) {
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        android.content.ClipData clip = android.content.ClipData.newPlainText(label, value);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, label + " copied", Toast.LENGTH_SHORT).show();
    }
}
