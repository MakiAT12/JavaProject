import java.util.*;
public class SumProgram {
   public static void main(String[] args){
      System.out.println("Sum:" + 
            (new Scanner(System.in).nextInt() +
             new Scanner(System.in).nextInt()));      
   }
}